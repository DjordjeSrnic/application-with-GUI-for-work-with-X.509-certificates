package implementation;

import java.util.Enumeration;

import code.GuiException;
import x509.v3.CodeV3;

public class MyCode extends CodeV3 {

	public MyCode(boolean[] algorithm_conf, boolean[] extensions_conf, boolean extensions_rules) throws GuiException {
		super(algorithm_conf, extensions_conf, extensions_rules);
		new Helper(access);
	}

	@Override
	public boolean canSign(String keypair_name) {
		return Helper.canSign(keypair_name);
	}

	@Override
	public boolean exportCSR(String file, String keypair_name, String algorithm) {
		return Helper.exportCSR(file, keypair_name, algorithm);
	}

	@Override
	public boolean exportCertificate(String file, String keypair_name, int encoding, int format) {
		return Helper.exportCertificate(file, keypair_name, encoding, format);
	}

	@Override
	public boolean exportKeypair(String keypair_name, String file, String password) {
		return Helper.exportKeypair(keypair_name, file, password);
	}

	@Override
	public String getCertPublicKeyAlgorithm(String keypair_name) {
		return Helper.getCertPublicKeyAlgorithm(keypair_name);
	}

	@Override
	public String getCertPublicKeyParameter(String keypair_name) {
		return Helper.getCertPublicKeyParameter(keypair_name);
	}

	@Override
	public String getSubjectInfo(String keypair_name) {
		return Helper.getSubjectInfo(keypair_name);
	}

	@Override
	public boolean importCAReply(String file, String keypair_name) {
		return Helper.importCAReply(file, keypair_name);
	}

	@Override
	public String importCSR(String file) {
		return Helper.importCSR(file);
	}

	@Override
	public boolean importCertificate(String file, String keypair_name) {
		return Helper.importCertificate(file, keypair_name);
	}

	@Override
	public boolean importKeypair(String keypair_name, String file, String password) {
		return Helper.importKeypair(keypair_name, file, password);
	}

	@Override
	public int loadKeypair(String keypair_name) {
		return Helper.loadKeypair(keypair_name);
	}

	@Override
	public Enumeration<String> loadLocalKeystore() {
		return Helper.loadLocalKeystore();
	}

	@Override
	public boolean removeKeypair(String keypair_name) {
		return Helper.removeKeypair(keypair_name);
	}

	@Override
	public void resetLocalKeystore() {
		Helper.resetLocalKeystore();
	}

	@Override
	public boolean saveKeypair(String keypair_name) {
		return Helper.saveKeypair(keypair_name);
	}

	@Override
	public boolean signCSR(String file, String keypair_name, String algorithm) {
		return Helper.signCSR(file, keypair_name, algorithm);
	}

}
