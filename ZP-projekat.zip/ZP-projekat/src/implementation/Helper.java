package implementation;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import sun.security.rsa.RSAPublicKeyImpl;
import x509.v3.GuiV3;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.io.Writer;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DEROutputStream;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x500.X500NameBuilder;
import org.bouncycastle.asn1.x500.style.BCStyle;
import org.bouncycastle.asn1.x500.style.IETFUtils;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.AuthorityKeyIdentifier;
import org.bouncycastle.asn1.x509.BasicConstraints;
import org.bouncycastle.asn1.x509.Extension;
import org.bouncycastle.asn1.x509.Extensions;
import org.bouncycastle.asn1.x509.ExtensionsGenerator;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.GeneralNames;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.X509v3CertificateBuilder;
import org.bouncycastle.cert.bc.BcX509ExtensionUtils;
import org.bouncycastle.cert.jcajce.JcaCertStore;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.CMSSignedDataGenerator;
import org.bouncycastle.cms.CMSTypedData;
import org.bouncycastle.cms.jcajce.JcaSignerInfoGeneratorBuilder;
import org.bouncycastle.jcajce.provider.asymmetric.rsa.BCRSAPublicKey;
import org.bouncycastle.jcajce.provider.asymmetric.x509.CertificateFactory;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMWriter;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.DefaultAlgorithmNameFinder;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.bouncycastle.operator.jcajce.JcaDigestCalculatorProviderBuilder;
import org.bouncycastle.pkcs.PKCS10CertificationRequest;
import org.bouncycastle.pkcs.PKCS10CertificationRequestBuilder;
import org.bouncycastle.pkcs.jcajce.JcaPKCS10CertificationRequestBuilder;
import org.bouncycastle.util.CollectionStore;
import org.bouncycastle.util.Store;
import org.bouncycastle.util.io.pem.PemObject;
import org.bouncycastle.util.io.pem.PemWriter;

import gui.Constants;

public class Helper {

	private static final String keyStoreName = "keyStore";
    private static final String keyStoreInstanceName = "PKCS12";
    private static final String keyStorePassword = "password";
    private static GuiV3 access;
    private static KeyStore keyStore;
    private static SubjectPublicKeyInfo spki;
    private static String TRUSTED_CERT="ETFrootCA";
    private static String subAltNames;
	
    public Helper(GuiV3 access) {
    	Helper.access = access;
    }
    
	public static Enumeration<String> loadLocalKeystore() {
		FileInputStream fis = null;
		FileOutputStream fos = null;
        try {
            keyStore = KeyStore.getInstance(keyStoreInstanceName, new BouncyCastleProvider());

            if (!(new File(keyStoreName).exists())) {
                keyStore.load(null, keyStorePassword.toCharArray());
                fos = new FileOutputStream(keyStoreName);
				keyStore.store(fos, keyStorePassword.toCharArray());
            } else {
                fis = new FileInputStream(keyStoreName);
                keyStore.load(fis, keyStorePassword.toCharArray());
                return keyStore.aliases();
            }
        } catch (Exception e) {
        	GuiV3.reportError(e);
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                	GuiV3.reportError(e);
                }
            }
        }
        return null;
	}
	
	public static void resetLocalKeystore() {
		try {
			KeyStore ks = KeyStore.getInstance(keyStoreInstanceName, new BouncyCastleProvider());
			ks.load(null, keyStorePassword.toCharArray());
			FileOutputStream output = new FileOutputStream(keyStoreName);
			
			ks.store(output, keyStorePassword.toCharArray());
			if (output != null) {
				output.close();
			}
			keyStore = ks;
		} catch (Exception e) {
			GuiV3.reportError(e);
		}
	}
	
	public static int loadKeypair(String keypair_name) {
		int ret = -1;
		String alias;
		 
		try {
			Enumeration<String> aliases = keyStore.aliases();
			
			while(aliases.hasMoreElements()) {
				alias = aliases.nextElement();
					
				if(alias.equals(keypair_name)) {
					X509Certificate cert;
					cert = (X509Certificate) keyStore.getCertificate(alias);
					
					JcaX509CertificateHolder certHolder = new JcaX509CertificateHolder(cert);
					String issuerName = certHolder.getIssuer().toString();
					String subjectName = certHolder.getSubject().toString();
					
					if (issuerName.equals(subjectName))
						ret = 0;
					else
						ret = 1;
					
					if (keypair_name.equals(TRUSTED_CERT)) 
                        ret = 2;
					
					setSubjectDataFromKeyStore(cert);
                
                    String s = cert.getIssuerDN().toString() + " ";
              
					access.setIssuer(
                            s.replaceAll(", ", ",")
                                    .replaceAll("=,", "= ,")
                                    .replaceAll("  ", " ")
                    );
            
                    X509Certificate issuer = (X509Certificate) keyStore.getCertificate(keypair_name);
                    if (issuer != null)
                        access.setIssuerSignatureAlgorithm(issuer.getSigAlgName());
                    else
                        access.setIssuerSignatureAlgorithm(cert.getSigAlgName());
                    
                    subAltNames = getAlternativeNames(cert);
                    
                    break;
				}
			}
		} catch (Exception e) {
			GuiV3.reportError(e);
		}
		return ret;
	}
    
	public static boolean saveKeypair(String keypair_name) {
		Subject subject = getSubjectDataFromGUI();
	
        KeyPair keyPair = null;
        try {
        	String publicKeyAlgorithm = access.getPublicKeyAlgorithm();
    		String publicKeyParameter = access.getPublicKeyParameter();
    		int publicKeyBitLength = Integer.parseInt(publicKeyParameter);
            keyPair = createKeyPair(publicKeyAlgorithm, publicKeyBitLength);
            PublicKey PUa = keyPair.getPublic();
            PrivateKey PRa = keyPair.getPrivate();
            X509Certificate certificate = createCertificate(PUa, PRa, subject);

            Certificate[] chain = new Certificate[1];
            chain[0] = certificate;
            keyStore.setKeyEntry(keypair_name, PRa, keyStorePassword.toCharArray(), chain);

            saveLocalKeyStore();
        } catch (Exception e) {
        	GuiV3.reportError(e);
            return false;
        }
        return true;
	}
	
	public static boolean removeKeypair(String keypair_name) {
		try {
            keyStore.deleteEntry(keypair_name);
            saveLocalKeyStore();
            loadLocalKeystore();
        } catch (KeyStoreException e) {
        	GuiV3.reportError(e);
            return false;
        }
        return true;
	}

	public static boolean importKeypair(String keypair_name, String file, String password) {
		try {
            FileInputStream fis = new FileInputStream(file);

            KeyStore tmpKeyStore = KeyStore.getInstance(keyStoreInstanceName, new BouncyCastleProvider());

            tmpKeyStore.load(fis, password.toCharArray()); 

            fis.close();
            Enumeration<String> aliases = tmpKeyStore.aliases();
            String selectedAlias = aliases.nextElement(); 

            Key key = tmpKeyStore.getKey(selectedAlias, password.toCharArray()); 
            Certificate[] chain = tmpKeyStore.getCertificateChain(selectedAlias); 

            keyStore.setKeyEntry(keypair_name, key, keyStorePassword.toCharArray(), chain);

            saveLocalKeyStore();
            
        } catch (Exception e) {
        	GuiV3.reportError(e);
            return false;
        }
        return true;
	}

	public static boolean exportKeypair(String keypair_name, String file, String password) {
		FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(file);
            KeyStore tmpKS = KeyStore.getInstance(keyStoreInstanceName, new BouncyCastleProvider());

            Key key = keyStore.getKey(keypair_name, keyStorePassword.toCharArray());
            Certificate[] chain = keyStore.getCertificateChain(keypair_name);

            tmpKS.load(null, null); 
            tmpKS.setKeyEntry(keypair_name, (PrivateKey) key, password.toCharArray(), chain);
            tmpKS.store(fos, password.toCharArray());
            return true;
        } catch (Exception e) {
        	GuiV3.reportError(e);
        } finally {
            if (fos != null)
                try {
                    fos.close();
                } catch (IOException e) {
                	GuiV3.reportError(e);
                }
        }
        return false;
	}
	
	public static boolean importCertificate(String file, String keypair_name) {
		try {
            
            if (keyStore.containsAlias(keypair_name)) {
				System.out.println("Certificate with name " + keypair_name + " already exsists.");
				return false;
			}

            FileInputStream fis = new FileInputStream(file);
            
            java.security.cert.CertificateFactory factory = java.security.cert.CertificateFactory.getInstance("X.509");
			java.security.cert.Certificate cert = factory.generateCertificate(fis);
			
			keyStore.setCertificateEntry(keypair_name, cert);
			saveLocalKeyStore();
            loadLocalKeystore();
        } catch (Exception e) {
        	GuiV3.reportError(e);
            return false;
        }
        return true;
	}
	
	public static boolean exportCertificate(String file, String keypair_name, int encoding, int format) {
        File newFile = new File(file);
        try {
        	Certificate[] chain = keyStore.getCertificateChain(keypair_name);
    		X509Certificate[] certChain = new X509Certificate[chain.length];
    		for(int i=0;i<chain.length;i++)
    			certChain[i] = (X509Certificate) chain[i];
            if (encoding == 1) {
                Writer writer = new FileWriter(newFile);
                PemWriter pemWriter = new PemWriter(writer);
                if (format == 1) {
                	for(int i=0;i<certChain.length;i++) {
                		PemObject pemObject = new PemObject(certChain[i].getType(), certChain[i].getEncoded());
                        pemWriter.writeObject(pemObject);
                	}
                } else if (format == 0) {
                	Certificate cert = keyStore.getCertificate(keypair_name);
                	PemObject pemObject = new PemObject(cert.getType(), cert.getEncoded());
                    pemWriter.writeObject(pemObject);
                } else {
                	pemWriter.flush();
                    pemWriter.close();
                    return false;
                }
                pemWriter.flush();
                pemWriter.close();
            } else if (encoding == 0) {
                FileOutputStream outputStream = new FileOutputStream(newFile);
                DEROutputStream dos = new DEROutputStream(outputStream);
                outputStream.write(certChain[0].getEncoded());
                if (format == 1) {
                	for(int i=0;i<certChain.length;i++) {
                		ASN1InputStream inputStream = new ASN1InputStream(new ByteArrayInputStream(certChain[i].getEncoded()));
                        dos.writeObject(inputStream.readObject());
                        inputStream.close();
                	}
                } else if (format == 0) {
                	ASN1InputStream inputStream = new ASN1InputStream(new ByteArrayInputStream(certChain[0].getEncoded()));
                    dos.writeObject(inputStream.readObject());
                    inputStream.close();
                } else {
                	dos.flush();
                    dos.close();
                    return false;
                }
                dos.flush();
                dos.close();
            } else
            	return false;
        } catch (Exception e) {
          GuiV3.reportError(e);
          return false;
        }
		return true;
	}

	public static boolean exportCSR(String file, String keypair_name, String algorithm) {
		X509Certificate cert = null;
        try {
            cert = (X509Certificate) keyStore.getCertificate(keypair_name);
        } catch (KeyStoreException e) {
        	GuiV3.reportError(e);
            return false;
        }
        PublicKey publicKey = cert.getPublicKey();
        PrivateKey privateKey = null;

        try {
            privateKey = (PrivateKey) keyStore.getKey(keypair_name, keyStorePassword.toCharArray());
        } catch (Exception e) {
        	GuiV3.reportError(e);
            return false;
        }

        PKCS10CertificationRequestBuilder p10Builder = new JcaPKCS10CertificationRequestBuilder(
                new X500Name(cert.getSubjectX500Principal().getName()), publicKey);

        ExtensionsGenerator extGen = new ExtensionsGenerator();

        ContentSigner signer = null;
        try {
            addExtensionsToGenerator(extGen, cert, null, null, null);
            p10Builder.addAttribute(PKCSObjectIdentifiers.pkcs_9_at_extensionRequest, extGen.generate());
            signer = new JcaContentSignerBuilder(algorithm).build(privateKey);
        } catch (Exception e) {
        	GuiV3.reportError(e);
            return false;
        }
        
        PKCS10CertificationRequest certificationRequest = p10Builder.build(signer);

        StringWriter strWriter = new StringWriter();
        JcaPEMWriter pemWriter = new JcaPEMWriter(strWriter);
        try {
            pemWriter.writeObject(certificationRequest);
            pemWriter.close();

            FileWriter fw = new FileWriter(new File(file));
            fw.write(strWriter.toString());
            fw.flush();
            fw.close();
        } catch (IOException e) {
        	GuiV3.reportError(e);
            return false;
        }
        return true;
	}
	
	public static String importCSR(String file) {
		try(BufferedReader br = new BufferedReader(new FileReader(file))) {
		    StringBuilder sb = new StringBuilder();
		    String line = br.readLine();

		    while (line != null) {
		        sb.append(line);
		        sb.append(System.lineSeparator());
		        line = br.readLine();
		    }
		    String csrAsString = sb.toString();
		    
		    try (final ByteArrayInputStream bais = new ByteArrayInputStream(csrAsString.getBytes());
		    	     final InputStreamReader isr = new InputStreamReader(bais, StandardCharsets.UTF_8);
		    	     final PEMParser pem = new PEMParser(isr))
		    {
		    	  	 PKCS10CertificationRequest csr = (PKCS10CertificationRequest) pem.readObject();
		    	  	 spki = csr.getSubjectPublicKeyInfo();
		    	  	 AlgorithmIdentifier signatureAlgorithm = csr.getSignatureAlgorithm();
					 String sigAlgName = new DefaultAlgorithmNameFinder().getAlgorithmName(signatureAlgorithm);
		    	  	 String[] array = csr.getSubject().toString().split(",");
					 String ret = "";
		    	  	 //String save = array[3];
		    	  	 for(int i=0;i<array.length;i++) {
		    	  		/*if (i==3)
		    	  			 ret += array[i+1];
		    	  		 else if (i==4)
		    	  			 ret += save;*/
		    	  		 /*else*/ if (array[i].split("=").length == 1)
		    	  			 ret+=array[i]+" ";
		    	  		 else
		    	  			ret+=array[i];
		    	  		 if (i<array.length-1)
		    	  			 ret+=",";
		    	  	 }
					 
		    	  	 access.setAlternativeName(Constants.SAN, subAltNames);
		    	  	 ret = ret + ", " + "SA=" + sigAlgName.replaceAll("WITH", "with");
		    	     return ret;
		    }
		} catch(Exception e) {
			GuiV3.reportError(e);
		}
		return null;
	}
	
	public static boolean signCSR(String file, String keypair_name, String algorithm) {
		FileOutputStream fos = null;
		try {
			Certificate[] chain = keyStore.getCertificateChain(keypair_name.toLowerCase());
            X509Certificate cert = (X509Certificate) chain[0];
            PrivateKey CAPrivateKey  = getPrivateKeyCA(keypair_name); //GET ISSUER PRIVATE KEY
            PublicKey CAPublicKey = getPublicKeyCA(keypair_name);
            
            String serNum = access.getSerialNumber();
            BigInteger serial = new BigInteger(serNum);
            
            Date issuedDate = access.getNotBefore();
            Date expiryDate = access.getNotAfter();

            String subject = access.getSubject();

            X509Certificate caCert = (X509Certificate)keyStore.getCertificate(keypair_name);
            X509CertificateHolder issuerCert = new X509CertificateHolder(caCert.getEncoded());
            
            X509v3CertificateBuilder certificateBuilder = new X509v3CertificateBuilder(
                    issuerCert.getSubject(), serial, issuedDate, expiryDate,
                    new X500Name(subject), spki);
            
            GeneralName genName = new GeneralName(4,caCert.getSubjectDN().getName());
            GeneralNames genNames = new GeneralNames(genName);
            ExtensionsGenerator extGen = new ExtensionsGenerator();
            addExtensionsToGenerator(extGen, cert, CAPublicKey, genNames, caCert.getSerialNumber());
            addExtensionsToBuilder(certificateBuilder, extGen.generate());
            
            ArrayList<Certificate> certs = new ArrayList<>();
            for(Certificate cer: chain)
				certs.add(cer);
            
            ContentSigner signer = new JcaContentSignerBuilder(algorithm).build(CAPrivateKey);
            
            X509Certificate signedCert = new JcaX509CertificateConverter()
                    .getCertificate(certificateBuilder.build(signer));

            Store certStore = new JcaCertStore(certs);
            
            fos = new FileOutputStream(file);
            
            CMSSignedDataGenerator cmsGen = new CMSSignedDataGenerator();
            cmsGen.addSignerInfoGenerator(new JcaSignerInfoGeneratorBuilder(new JcaDigestCalculatorProviderBuilder().build()).build(signer, new X509CertificateHolder(chain[0].getEncoded())));
            cmsGen.addCertificates(certStore);
            CMSSignedData signed = cmsGen.generate(new CMSProcessableByteArray(PKCSObjectIdentifiers.x509Certificate, signedCert.getEncoded()),true);
            fos.write(signed.getEncoded());
		} catch (Exception e) {
			GuiV3.reportError(e);
            return false;
        } finally {
			if (fos != null)
                try {
                    fos.close();
                } catch (IOException e) {
                	GuiV3.reportError(e);
                }
        }
        return true;
	}

	public static boolean importCAReply(String file, String keypair_name) {
		try {
			FileInputStream is = new FileInputStream(file);
			CMSSignedData signedData = new CMSSignedData(is);
			
			//Getting signed certificate.
			CMSTypedData ctd = signedData.getSignedContent();
			
			if (ctd.getContentType() != PKCSObjectIdentifiers.x509Certificate || !(ctd instanceof CMSProcessableByteArray)) {
				System.out.println("Unknown signed content.");
				return false;
			}

			//Getting signing certificates.
			CollectionStore certs = (CollectionStore)signedData.getCertificates();
			
			//Reading signed certificate as byte array.
			CMSProcessableByteArray data = (CMSProcessableByteArray)ctd;
			InputStream in = data.getInputStream();
			
			//Converting byte array to certificate object.
			CertificateFactory factory = new CertificateFactory();
			
			java.security.cert.Certificate javaCert = factory.engineGenerateCertificate(in);
			
			//Setting signed certificate in key store.
			if (keyStore.isKeyEntry(keypair_name)) {
				Key key = keyStore.getKey(keypair_name, keyStorePassword.toCharArray());
				
				keyStore.deleteEntry(keypair_name);
				
				Iterator<X509CertificateHolder> it = certs.iterator();
				ArrayList<java.security.cert.Certificate> listChain = new ArrayList<>();
				while(it.hasNext()) {
					listChain.add(factory.engineGenerateCertificate(new ASN1InputStream(it.next().getEncoded())));
				}
				
				java.security.cert.Certificate[] chain = new java.security.cert.Certificate[listChain.size() + 1];
				chain[0] = javaCert;
				for(int i = 0; i < listChain.size(); i++) {
					chain[i + 1] = listChain.get(i);
				}
				
				keyStore.setKeyEntry(keypair_name, key, keyStorePassword.toCharArray(), chain);
			}
			else {
				keyStore.deleteEntry(keypair_name);
				
				keyStore.setCertificateEntry(keypair_name, javaCert);
			}
			saveLocalKeyStore();
		} catch (Exception e) {
			GuiV3.reportError(e);
			return false;
		}
		return true;
	}

	public static boolean canSign(String keypair_name) {
		X509Certificate cert = null;
        try {
			cert = (X509Certificate) keyStore.getCertificate(keypair_name);
			X509CertificateHolder x509 = new X509CertificateHolder(cert.getEncoded());

			Extension bcExt = x509.getExtension(Extension.basicConstraints);
			BasicConstraints bc = null;
			
			if (bcExt != null) {
				bc = BasicConstraints.fromExtensions(new Extensions(bcExt));
			}
			else {
				return false;
			}

			return bc == null ? false : bc.isCA();
			
		} catch (Exception e) {
			GuiV3.reportError(e);
		}
		return false;
	}
	
	public static String getSubjectInfo(String keypair_name) {
		try {
			X509Certificate cert = findCertificate(keyStore, keypair_name);
			X509CertificateHolder x509 = new X509CertificateHolder(cert.getEncoded());
			X500Name subject = x509.getSubject();
			
			if (subject != null) 
				return subject.toString();
			else 
				return null;
		} catch (Exception e) {
			GuiV3.reportError(e);
		}
		return null;
		
	}

	public static String getCertPublicKeyAlgorithm(String keypair_name) {
		try {
			return findCertificate(keyStore, keypair_name).getPublicKey().getAlgorithm();
		} catch (Exception e) {
			GuiV3.reportError(e);
		}
		return null;
	}

	public static String getCertPublicKeyParameter(String keypair_name) {
		try {
			if (!keyStore.containsAlias(keypair_name)) {
				return null;
			}
			
			java.security.cert.Certificate cert = keyStore.getCertificate(keypair_name);

			CertificateFactory factory = new CertificateFactory();
			X509Certificate javaCert = (X509Certificate) factory.engineGenerateCertificate(new ByteArrayInputStream(cert.getEncoded()));

			PublicKey pk = javaCert.getPublicKey();
			BCRSAPublicKey bcPk = (BCRSAPublicKey)pk;

			int bitLen = bcPk.getModulus().bitLength();

			return bitLen + "";
		} catch (Exception e) {
			GuiV3.reportError(e);
			return null;
		}
	}

	
	//=========================================================================================================== PRIVATE METHODS
	
	private static void setSubjectDataFromKeyStore(X509Certificate certificate) throws Exception {
        JcaX509CertificateHolder certHolder = new JcaX509CertificateHolder((X509Certificate) certificate);
        X500Name name = certHolder.getSubject();

        access.setVersion(certHolder.getVersionNumber() - 1); //because index of buttons[] should be -1

        if (name.getRDNs(BCStyle.C).length > 0)
            access.setSubjectCountry(IETFUtils.valueToString(name.getRDNs(BCStyle.C)[0].getFirst().getValue()));
        if (name.getRDNs(BCStyle.ST).length > 0)
            access.setSubjectState(IETFUtils.valueToString(name.getRDNs(BCStyle.ST)[0].getFirst().getValue()));
        if (name.getRDNs(BCStyle.L).length > 0)
            access.setSubjectLocality(IETFUtils.valueToString(name.getRDNs(BCStyle.L)[0].getFirst().getValue()));
        if (name.getRDNs(BCStyle.O).length > 0)
            access.setSubjectOrganization(IETFUtils.valueToString(name.getRDNs(BCStyle.O)[0].getFirst().getValue()));
        if (name.getRDNs(BCStyle.OU).length > 0)
            access.setSubjectOrganizationUnit(IETFUtils.valueToString(name.getRDNs(BCStyle.OU)[0].getFirst().getValue()));
        if (name.getRDNs(BCStyle.CN).length > 0)
            access.setSubjectCommonName(IETFUtils.valueToString(name.getRDNs(BCStyle.CN)[0].getFirst().getValue()));
        access.setSubjectSignatureAlgorithm(certificate.getSigAlgName());
        access.setPublicKeyAlgorithm(certificate.getSigAlgName());
        if (certificate.getPublicKey() instanceof RSAPublicKeyImpl) {
            access.setPublicKeyParameter("" +
                    ((RSAPublicKeyImpl) certificate.getPublicKey()).getModulus().bitLength());
        } else {
            access.setPublicKeyParameter("" +
                    ((org.bouncycastle.jcajce.provider.asymmetric.rsa.BCRSAPublicKey) certificate.getPublicKey()).getModulus().bitLength()
            );
        }

        access.setSerialNumber(String.valueOf(certificate.getSerialNumber()));
        access.setNotBefore(certificate.getNotBefore());
        access.setNotAfter(certificate.getNotAfter());

        //=========GET AUTHORITY KEY IDENTIFIER=================

    	
        Extension akiExt = certHolder.getExtension(Extension.authorityKeyIdentifier);
        
    	if (akiExt == null) {
    		access.setEnabledAuthorityKeyID(false);
    		access.setCritical(Constants.AKID, false);
    	} else {
    		AuthorityKeyIdentifier aki =null;
    		try {
    			aki = AuthorityKeyIdentifier.fromExtensions(new Extensions(akiExt));
    	    } catch (IllegalArgumentException ex) {
    	        throw new CertificateEncodingException("invalid extension AuthorityKeyIdentifier: " + ex.getMessage());
    	    }
    		if (aki==null)
    			return;
    		access.setEnabledAuthorityKeyID(true);
    		access.setCritical(Constants.AKID, akiExt.isCritical());
    		access.setAuthorityKeyID(aki.getKeyIdentifier().toString());
    		
    		String[] sArray = aki.getAuthorityCertIssuer().toString().split(",");
            String commonName = getCNCustom(sArray);
    		access.setAuthorityIssuer(commonName);
    		access.setAuthoritySerialNumber(aki.getAuthorityCertSerialNumber().toString());
    	}
    	
        //=========GET SUBJECT ALTERNATIVE NAMES=========
    	Extension san = certHolder.getExtension(Extension.subjectAlternativeName);
    	if (san!=null) {
    		String subjectAltNames = getAlternativeNames(certificate);
            if (!"".equals(subjectAltNames)) {
            	access.setAlternativeName(Constants.SAN, subjectAltNames);
            	access.setCritical(Constants.SAN, san.isCritical());
            }
    	}
        
        //========GET BASIC CONSTRAINTS=========
        Extension bcExt = certHolder.getExtension(Extension.basicConstraints);
		BasicConstraints bc = null;
		if (bcExt != null) {
			bc = BasicConstraints.fromExtensions(new Extensions(bcExt));
		}
		if (bcExt != null) {
			access.setCA(bc.isCA());
			access.setCritical(Constants.BC, bcExt.isCritical());
			if (bc.isCA() && (bc.getPathLenConstraint() != null)) {
				access.setPathLen(bc.getPathLenConstraint().toString());
			}
		}
		else {
			access.setCA(false);
		}
	}

	private static String getAlternativeNames(X509Certificate certificate) throws Exception {
		StringBuilder sb = new StringBuilder();
		Collection<List<?>> sans = certificate.getSubjectAlternativeNames();
		if (sans != null) {
			for(List<?> list: sans) {
				Integer fieldTag = null;
				String fieldValue = null;
				
				for(Object elem: list) {
					if (elem instanceof Integer && fieldTag == null) {
						fieldTag = (Integer) elem;
					}
					else {
						fieldValue = elem.toString();
					}
				}
				String fieldName = null;
				
				switch(fieldTag) {
				case GeneralName.iPAddress:
					fieldName = "iPAddress";
					break;
				case GeneralName.uniformResourceIdentifier:
					fieldName = "uniformResourceIdentifier";
					break;
				case GeneralName.dNSName:
					fieldName = "dNSName";		
					break;
				case GeneralName.directoryName:
					fieldName = "directoryName";
					break;
				case GeneralName.rfc822Name:
					fieldName = "rfc822name" ;
					break;
				case GeneralName.x400Address:
					fieldName = "x400Address";
					break;
				case GeneralName.ediPartyName:
					fieldName = "ediPartyName";
					break;
				case GeneralName.registeredID:
					fieldName = "registredID";
					break;
				case GeneralName.otherName:
					fieldName = "otherName";
					break;
				default:
					throw new Exception("Unknown name type.");
				}
				
				sb.append(fieldName + "=" + fieldValue + ",");
			}
			if (sb.length() != 0) {
				sb.deleteCharAt(sb.length() - 1);
			}
		}
		
		return sb.toString();
	}
	
	private static String getCNCustom(String[] sArray) {
		for (int i = 0; i < sArray.length; i++) {
            String s = sArray[i];
            if (s.contains("CN"))
                return s.split("=")[1];
        }
        return "";
	}

	private static void saveLocalKeyStore() {
		FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(keyStoreName);
            keyStore.store(fos, keyStorePassword.toCharArray());
        } catch (Exception e) {
        	GuiV3.reportError(e);
        } finally {
            if (fos != null)
                try {
                    fos.close();
                } catch (IOException e) {
                	GuiV3.reportError(e);
                }
        }
	}

	private static X509Certificate createCertificate(PublicKey publicKey, PrivateKey privateKey, Subject subject) throws Exception {
		X500NameBuilder builder = new X500NameBuilder(BCStyle.INSTANCE);
        builder.addRDN(BCStyle.CN, subject.getCN());
        builder.addRDN(BCStyle.O, subject.getO());
        builder.addRDN(BCStyle.OU, subject.getOU());
        builder.addRDN(BCStyle.L, subject.getL());
        builder.addRDN(BCStyle.ST, subject.getST());
        builder.addRDN(BCStyle.C, subject.getC());

        String sigAlg = subject.getSA();
        
        ContentSigner sigGen = new JcaContentSignerBuilder(sigAlg).build(privateKey);
        
        X509v3CertificateBuilder certGen = null;
        
        certGen = new JcaX509v3CertificateBuilder(
                builder.build(),
                new BigInteger(subject.getSN()), subject.getValidNotBefore(), subject.getValidNotAfter(),
                builder.build(),
                publicKey);   

        //===========SUBJECT ALTERNATIVE NAMES===========

        boolean criticalSAN = subject.isSubjectAlternativeNameCritical();
        String[] arr = subject.getSubjectAlternativeNames();

        for(int i=0;i<arr.length;i++)
        	System.out.println(arr[i]);
        if (subject.getSubjectAlternativeNames().length > 0) {
            GeneralName[] all = new GeneralName[subject.getSubjectAlternativeNames().length];
            int i = 0;
            for (String it : subject.getSubjectAlternativeNames()) {
    			String nameType = it.substring(0, it.indexOf('='));
    			String nameValue = it.substring(it.indexOf('=') + 1);
    			
    			
    			int tag = 0;
    			switch(nameType) {
    			case "directoryName":
    				tag = GeneralName.directoryName;
    				break;
    			case "dNSName":
    				tag = GeneralName.dNSName;
    				break;
    			case "ediPartyName":
    				tag = GeneralName.ediPartyName;
    				break;
    			case "iPAddress":
    				tag = GeneralName.iPAddress;
    				break;
    			case "otherName":
    				tag = GeneralName.otherName;
    				break;
    			case "registredID":
    				tag = GeneralName.registeredID;
    				break;
    			case "rfc822Name":
    				tag = GeneralName.rfc822Name;
    				break;
    			case "uniformResourceIdentifier":
    				tag = GeneralName.uniformResourceIdentifier;
    				break;
    			case "x400Address":
    				tag = GeneralName.x400Address;
    				break;
    			default:
    				throw new Exception("Unknown name type.");
    			}

    			GeneralName generalName = new GeneralName(tag, nameValue);
    			all[i++] = generalName;
            }
            
            GeneralNames names = new GeneralNames(all);
			certGen.addExtension(Extension.subjectAlternativeName, criticalSAN, names);
        }

        //===========BASIC CONSTRAINTS===========
        
        boolean criticalBC = subject.isBasicConstraintsCritical();
        boolean isCA = subject.getBasicConstraintsIsCA();
        int pathLen = subject.getBasicConstraintsPathLength();
        if (isCA)
        	certGen.addExtension(Extension.basicConstraints, criticalBC, new BasicConstraints(pathLen));


        //========FINAL BUILD========
        X509Certificate cert = null;
		cert = new JcaX509CertificateConverter().getCertificate(certGen.build(sigGen));  
        System.out.println("CREATION: "+ cert); //DEBUG
        return cert;
	}

	private static KeyPair createKeyPair(String encryptType, int bitCount) {
		KeyPairGenerator kpg;
		try {
			kpg = KeyPairGenerator.getInstance(encryptType);
			kpg.initialize(bitCount);
	        return kpg.genKeyPair();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return null;
        
	}

	private static Subject getSubjectDataFromGUI() {
		Subject ret = new Subject(
                access.getSubjectCountry(),
                access.getSubjectState(),
                access.getSubjectLocality(),
                access.getSubjectOrganization(),
                access.getSubjectOrganizationUnit(),
                access.getSubjectCommonName(),
                access.getPublicKeyDigestAlgorithm(),
                access.getSerialNumber(),
                access.getPublicKeyParameter(),
                access.getNotBefore(),
                access.getNotAfter(),
                access.getEnabledAuthorityKeyID(),
                access.getAlternativeName(5), 
                access.isCA(),
                access.getVersion()
        );
		String[] arr = access.getAlternativeName(Constants.SAN);
		System.out.println("ALTERNATIVE NAMES");
		for(int i=0;i<arr.length;i++)
			System.out.println(arr[i]);
		
        ret.setAuthorityKeyIdentifierCritical(
                access.isCritical(0) 
        );
        ret.setSubjectAlternativeNameCritical(
                access.isCritical(5) 
        );
        ret.setBasicConstraintsCritical(
                access.isCritical(8) 
        );
        if (ret.isBasicConstraintsCritical())
        	ret.setBasicConstraintsPathLength(
            		access.getPathLen() 
            );
        return ret;
	}
	
	private static void addExtensionsToGenerator(ExtensionsGenerator extGen, X509Certificate cert, PublicKey CAPublicKey, GeneralNames genNames, BigInteger serialNumber) throws Exception {
		
    	//===========ADD AUTHORITY KEY IDENTIFIER===========
    	
    	if (CAPublicKey != null && genNames != null && serialNumber != null) {
    		SubjectPublicKeyInfo info = SubjectPublicKeyInfo.getInstance(CAPublicKey.getEncoded());
    		
    		AuthorityKeyIdentifier keyId = new AuthorityKeyIdentifier(info.getEncoded(),genNames,serialNumber);
    		boolean akiCrit = access.isCritical(Constants.AKID);
    		boolean akiEnabled = access.getEnabledAuthorityKeyID();
    		
    		if (akiEnabled)
    			extGen.addExtension(Extension.authorityKeyIdentifier, akiCrit, keyId);
    	}
    	
    	//===========ADD SUBJECT ALTERNATIVE NAMES===========
    	
    	String[] san = access.getAlternativeName(Constants.SAN);
    	System.out.println("SANSIZE: " + san.length);
    	
    	if (san.length == 0)
    		san = subAltNames.split(" ");
    	
    	if (san.length != 0) {
    		boolean sanCritical = access.isCritical(Constants.SAN);
        	
    		ArrayList<GeneralName> generalNames = new ArrayList<>();
    		
    		for(String name: san) {
    			name = name.trim();
    			String nameType = name.substring(0, name.indexOf('='));
    			String nameValue = name.substring(name.indexOf('=') + 1);
    			
    			
    			int tag = 0;
    			switch(nameType) {
    			case "directoryName":
    				tag = GeneralName.directoryName;
    				break;
    			case "dNSName":
    				tag = GeneralName.dNSName;
    				break;
    			case "ediPartyName":
    				tag = GeneralName.ediPartyName;
    				break;
    			case "iPAddress":
    				tag = GeneralName.iPAddress;
    				break;
    			case "otherName":
    				tag = GeneralName.otherName;
    				break;
    			case "registredID":
    				tag = GeneralName.registeredID;
    				break;
    			case "rfc822Name":
    				tag = GeneralName.rfc822Name;
    				break;
    			case "uniformResourceIdentifier":
    				tag = GeneralName.uniformResourceIdentifier;
    				break;
    			case "x400Address":
    				tag = GeneralName.x400Address;
    				break;
    			default:
    				throw new Exception("Unknown name type.");
    			}

    			GeneralName generalName = new GeneralName(tag, nameValue);
    			generalNames.add(generalName);
    		}
    		GeneralName[] array = new GeneralName[generalNames.size()];
    		int i = 0;
    		for(GeneralName gn:generalNames) {
    			array[i++] = gn;
    		}
    		GeneralNames names = new GeneralNames(array);
    		
    		if (names != null) 
    			extGen.addExtension(Extension.subjectAlternativeName, sanCritical, (ASN1Encodable) names);
    	}
		     
        //===========ADD BASIC CONSTRAINTS===========
        
        boolean isCA = access.isCA();
        int pathLen;
        boolean hasPath = false;
		try {
			pathLen = Integer.parseInt(access.getPathLen());
			hasPath = true;
		}
		catch (Exception e) {
			pathLen = 0;
		}
        
        if (isCA && hasPath) 
        	extGen.addExtension(Extension.basicConstraints, access.isCritical(Constants.BC), new BasicConstraints(pathLen));
		
		else 
			extGen.addExtension(Extension.basicConstraints, access.isCritical(Constants.BC), new BasicConstraints(isCA)); 	
	
	}

	private static X509Certificate findCertificate(KeyStore keyStore, String keypair_name) throws Exception {
        X509Certificate certificate = (X509Certificate) keyStore.getCertificate(keypair_name);
        return certificate;
	}
	
	private static PrivateKey getPrivateKeyCA(String keypair_name) throws Exception {
		PrivateKey ret = null;
        
		Enumeration<String> aliases = keyStore.aliases();
        while (true) {
            String selectedAlias = aliases.nextElement();
            if (selectedAlias.equals(keypair_name)) {
                ret = (PrivateKey) keyStore.getKey(keypair_name, keyStorePassword.toCharArray());
                break;
            }
        }   
        
        return ret;
	}
	
	private static PublicKey getPublicKeyCA(String nameOfIssuer) throws Exception {
		 PublicKey ret = null;
	       
		 Enumeration<String> aliases = keyStore.aliases();
         while (true) {
             String selectedAlias;
             if (aliases.hasMoreElements())
                 selectedAlias = aliases.nextElement();
             else break;
             String s = ((X509Certificate) keyStore.getCertificate(selectedAlias)).getSubjectDN().getName();
             String[] sArray = s.split(",");
             String commonName = getCNCustom(sArray);
             if (selectedAlias.equals(nameOfIssuer) || nameOfIssuer.equals(commonName)) {
                 X509Certificate certificate = (X509Certificate) keyStore.getCertificate(selectedAlias);
                 ret = certificate.getPublicKey();
                 break;
             }
         }       
	       
	     return ret;
	}

	private static void addExtensionsToBuilder(X509v3CertificateBuilder certificateBuilder, Extensions allExt) throws Exception {
		ASN1ObjectIdentifier[] allId = allExt.getExtensionOIDs();
        for (ASN1ObjectIdentifier aoi : allId)
            certificateBuilder.addExtension(allExt.getExtension(aoi));
	}
}