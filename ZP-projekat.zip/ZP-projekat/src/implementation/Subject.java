package implementation;

import java.util.Date;

public class Subject {

    //Certificate Subject

    /**
     * Country
     */
    private String C;
    /**
     * State
     */
    private String ST;
    /**
     * Locality
     */
    private String L;
    /**
     * Organization
     */
    private String O;
    /**
     * Organization unit
     */
    private String OU;
    /**
     * Common name
     */
    private String CN;
    /**
     * Signature Algorithm
     */
    private String SA;


    /**
     * Serial Number
     */
    private String SN;

    /**
     * RSA Key length {512,1024,2048,4096}
     */
    private String keyLength;

    /**
     * Valid not before
     */
    private Date validNotBefore;

    /**
     * Valid not after
     */
    private Date validNotAfter;

    //ISSUER SUBJECT

    private String iC;
    private String iST;
    private String iL;
    private String iO;
    private String iOU;
    private String iCN;
    private String iSN;
    private boolean authorityKeyIdentifierCritical;
    private boolean authorityKeyIdentifierEnabled;
    private String[] subjectAlternativeNames;
    private boolean subjectAlternativeNameCritical;
    private boolean basicConstraintsCritical;
    private boolean basicConstraintsIsCA;
    private int basicConstraintsPathLength;
    private int version;

    public Subject(String C, String ST, String L, String O, String OU, String CN, String SA,
                              String SN, String keyLength, Date validNotBefore, Date validNotAfter,
                              boolean authorityKeyIdentifierEnabled, String[] subjectAlternativeNames, boolean basicConstraintsIsCA, int version) {
        this.C = C;
        this.ST = ST;
        this.L = L;
        this.O = O;
        this.OU = OU;
        this.CN = CN;
        this.SA = SA;
        this.SN = SN;
        this.keyLength = keyLength;
        this.validNotBefore = validNotBefore;
        this.validNotAfter = validNotAfter;
        this.authorityKeyIdentifierEnabled = authorityKeyIdentifierEnabled;
        this.subjectAlternativeNames = subjectAlternativeNames;
        this.basicConstraintsIsCA = basicConstraintsIsCA;
        this.version = version;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public String getSubjectAlternativeName(int index){
        if(index > 0 && index < subjectAlternativeNames.length)
            return subjectAlternativeNames[index];
        throw new IndexOutOfBoundsException();
    }

    public boolean isAuthorityKeyIdentifierCritical() {
        return authorityKeyIdentifierCritical;
    }

    public void setAuthorityKeyIdentifierCritical(boolean authorityKeyIdentifierCritical) {
        this.authorityKeyIdentifierCritical = authorityKeyIdentifierCritical;
    }

    public boolean isSubjectAlternativeNameCritical() {
        return subjectAlternativeNameCritical;
    }

    public void setSubjectAlternativeNameCritical(boolean subjectAlternativeNameCritical) {
        this.subjectAlternativeNameCritical = subjectAlternativeNameCritical;
    }

    public boolean isBasicConstraintsCritical() {
        return basicConstraintsCritical;
    }

    public void setBasicConstraintsCritical(boolean basicConstraintsCritical) {
        this.basicConstraintsCritical = basicConstraintsCritical;
    }

    public String getC() {
        return C;
    }

    public void setC(String c) {
        C = c;
    }

    public String getST() {
        return ST;
    }

    public void setST(String ST) {
        this.ST = ST;
    }

    public String getL() {
        return L;
    }

    public void setL(String l) {
        L = l;
    }

    public String getO() {
        return O;
    }

    public void setO(String o) {
        O = o;
    }

    public String getOU() {
        return OU;
    }

    public void setOU(String OU) {
        this.OU = OU;
    }

    public String getCN() {
        return CN;
    }

    public void setCN(String CN) {
        this.CN = CN;
    }

    public String getSA() {
        return SA;
    }

    public void setSA(String SA) {
        this.SA = SA;
    }

    public String getSN() {
        return SN;
    }

    public void setSN(String SN) {
        this.SN = SN;
    }

    public String getKeyLength() {
        return keyLength;
    }

    public void setKeyLength(String keyLength) {
        this.keyLength = keyLength;
    }

    public Date getValidNotBefore() {
        return validNotBefore;
    }

    public void setValidNotBefore(Date validNotBefore) {
        this.validNotBefore = validNotBefore;
    }

    public Date getValidNotAfter() {
        return validNotAfter;
    }

    public void setValidNotAfter(Date validNotAfter) {
        this.validNotAfter = validNotAfter;
    }
    
    public boolean isAuthorityKeyIdentifierEnabled() {
    	return authorityKeyIdentifierEnabled;
    }
    
    public void setAuthorityKeyIdentifierEnabled(boolean authorityKeyIdentifierEnabled) {
    	this.authorityKeyIdentifierEnabled = authorityKeyIdentifierEnabled;
    }
    
    public String[] getSubjectAlternativeNames() {
        return subjectAlternativeNames;
    }

    public void setSubjectAlternativeNames(String[] subjectAlternativeNames) {
        this.subjectAlternativeNames = subjectAlternativeNames;
    }
    
    public boolean getBasicConstraintsIsCA() {
    	return basicConstraintsIsCA;
    }
    
    public void setBasicConstraintsIsCA(boolean basicConstraintsIsCA) {
    	this.basicConstraintsIsCA = basicConstraintsIsCA;
    }
    
    public void setBasicConstraintsPathLength(String len) {
    	this.basicConstraintsPathLength = Integer.parseInt(len);
    }
    
    public int getBasicConstraintsPathLength() {
    	return basicConstraintsPathLength;
    }

    public String getiC() {
        return iC;
    }

    public void setiC(String iC) {
        this.iC = iC;
    }

    public String getiST() {
        return iST;
    }

    public void setiST(String iST) {
        this.iST = iST;
    }

    public String getiL() {
        return iL;
    }

    public void setiL(String iL) {
        this.iL = iL;
    }

    public String getiO() {
        return iO;
    }

    public void setiO(String iO) {
        this.iO = iO;
    }

    public String getiOU() {
        return iOU;
    }

    public void setiOU(String iOU) {
        this.iOU = iOU;
    }

    public String getiCN() {
        return iCN;
    }

    public void setiCN(String iCN) {
        this.iCN = iCN;
    }

    public String getiSN() {
        return iSN;
    }

    public void setiSN(String iSN) {
        this.iSN = iSN;
    }
}